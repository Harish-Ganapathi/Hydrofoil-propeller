

foamCleanTutorials
blockMesh
surfaceFeatures
decomposePar
mpirun -np 12 snappyHexMesh -parallel -overwrite

reconstructPar -constant
#checkMesh

#renumberMesh -overwrite
#transformPoints "scale=(0.0001 0.0001 0.0001)"


createBaffles -overwrite
splitBaffles -overwrite



createNonConformalCouples -overwrite NCC1 NCC2



foamRun -solver movingMesh -noFunctionObjects

#checkMesh -latestTime


rm -rf 0 
cp -r 0_org 0 

#series run
#renumberMesh -overwrite -noFunctionObject
#foamRun | tee log.solver


#parallel run
#decomposePar
#mpirun -np 10 renumberMesh -overwrite -noFunctionObjects -parallel | tee log.decomposepar
#mpirun -np 12 foamRun -parallel | tee log.solver
#mpirun -np 12 foamRun -parallel 
#mpirun -np 12 foamPostProcess -func Q -parallel | tee log.Q
